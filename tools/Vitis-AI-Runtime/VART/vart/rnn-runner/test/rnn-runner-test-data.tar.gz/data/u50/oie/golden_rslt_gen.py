import os
import numpy as np
import math

f_in = "./bench_bin_compiler"
f_out = "./bench_bin"
#bytes number of data
out_c = 16  
#lines number of data in rslt file
out_r = 2360  # oie_59 59*320*2/16=2360
#out_r = 8000  # sentiment_500 500*128*2/16=8000
 
buf_byte_int = 0

if os.path.isfile(f_in):
  print("Open input file: {} ".format(f_in))  
else:
  print("{} doesn't exist".format(f_in))

d_array = np.empty((out_r, out_c), dtype=np.uint8)
(R,C)=d_array.shape
with open(f_in, "r") as f_input:
  for r in range(0, out_r, 1):
    line_buf = f_input.readline()
    ll = "".join(line_buf)
    for c in range(0, out_c, 1):   #c <-> bytes index in line
      #print("index_{}: 0x{}{} ".format(((-1)-(c*2)), ll[(-3)-(c*2)], ll[(-2)-(c*2)]))
      buf_byte_int = 16 * int(ll[(-3)-(c*2)], base=16) + int(ll[(-2)-(c*2)], base=16)
      d_array[r][c] = buf_byte_int

d_array.tofile(f_out)



