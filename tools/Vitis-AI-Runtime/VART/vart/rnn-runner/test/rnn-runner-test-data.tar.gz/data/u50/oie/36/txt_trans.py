import os
import numpy as np
import math

f_in = "./txt_input"
f_out = "./binary_bin"
h_dim = 32

if os.path.isfile(f_in):
  in_array = np.loadtxt(f_in, dtype = np.uint16)
else:
  print("{} doesn't exist".format(f_w))

(R,C)=in_array.shape
print("input shape: R-{}, C-{}".format(R,C))

c_paded = math.ceil(C/h_dim)*h_dim

d_array = np.zeros([R, c_paded], dtype=np.uint16)
for r in range (0, R, 1):
  for c in range(0, C, 1):
    d_array[r][c] = in_array[r][c]

d_array.tofile(f_out)

#  out_data = data
#    if data.ndim == 2:
#      (row, col) = data.shape
#      vert_pad = math.ceil(row/shape[0])*shape[0] - row
#      horiz_pad = math.ceil(col/shape[1])*shape[1] - col
#      
#      if vert_pad != 0:
#        out_data = np.concatenate((out_data, np.zeros((vert_pad, col), dtype = np.int16)), axis = 0)
#      if horiz_pad != 0:
#        out_data = np.concatenate((out_data, np.zeros((row+vert_pad, horiz_pad), dtype = np.int16)), axis = 1)
#    elif data.ndim == 1:
#      len = data.size
#      pad_len = math.ceil(len/shape)*shape - len
#      out_data = np.concatenate((out_data, np.zeros(pad_len, dtype = np.int16)), axis = 0)
#      
#
#    return out_data


